// $ANTLR 3.0.1 E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g 2008-03-12 11:55:02

	package org.wikipedia.vlsergey.parser.table;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

public class TableLexer extends Lexer {
    public static final int COLUMNBREAKBORDERTEXT=21;
    public static final int NEWLINECELLBORDERTEXT=18;
    public static final int SAMELINECELLBORDERTEXT=20;
    public static final int COLUMNBREAKBORDER=12;
    public static final int EXCLM=23;
    public static final int CELL=6;
    public static final int COLUMNBREAKATTRIBUTES=13;
    public static final int CELLBORDER=9;
    public static final int MINUS=24;
    public static final int LITERALS=22;
    public static final int CELLATTRIBUTES=7;
    public static final int Tokens=26;
    public static final int EOF=-1;
    public static final int SPACE=16;
    public static final int LINE=19;
    public static final int CELLATTRIBUTESBORDER=8;
    public static final int TABLETAIL=5;
    public static final int NEWLINE=25;
    public static final int LEXNEWLINE=15;
    public static final int NEWLINETRIPLELINE=17;
    public static final int TABLEATTRIBUTES=4;
    public static final int COLUMNBREAKTAIL=14;
    public static final int CELLCHILDREN=10;
    public static final int COLUMNBREAK=11;
    
        @Override
        public void reportError(RecognitionException exc) {
            String header = getErrorHeader(exc);
            String message = getErrorMessage(exc, getTokenNames());
            String strExc = header + " " + message + " (" + exc.getMessage() + ")";
            throw new org.wikipedia.vlsergey.parser.ParsingException(strExc, exc);
        }

    public TableLexer() {;} 
    public TableLexer(CharStream input) {
        super(input);
    }
    public String getGrammarFileName() { return "E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g"; }

    // $ANTLR start NEWLINETRIPLELINE
    public final void mNEWLINETRIPLELINE() throws RecognitionException {
        try {
            int _type = NEWLINETRIPLELINE;
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:143:2: ( NEWLINE ( SPACE )* ( EXCLM | LINE ) LINE LINE )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:143:4: NEWLINE ( SPACE )* ( EXCLM | LINE ) LINE LINE
            {
            mNEWLINE(); 
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:143:12: ( SPACE )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( (LA1_0=='\t'||LA1_0==' ') ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:143:12: SPACE
            	    {
            	    mSPACE(); 

            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);

            if ( input.LA(1)=='!'||input.LA(1)=='|' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }

            mLINE(); 
            mLINE(); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end NEWLINETRIPLELINE

    // $ANTLR start SAMELINECELLBORDERTEXT
    public final void mSAMELINECELLBORDERTEXT() throws RecognitionException {
        try {
            int _type = SAMELINECELLBORDERTEXT;
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:146:2: ( LINE LINE )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:146:4: LINE LINE
            {
            mLINE(); 
            mLINE(); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end SAMELINECELLBORDERTEXT

    // $ANTLR start NEWLINECELLBORDERTEXT
    public final void mNEWLINECELLBORDERTEXT() throws RecognitionException {
        try {
            int _type = NEWLINECELLBORDERTEXT;
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:148:2: ( NEWLINE ( SPACE )* ( EXCLM | LINE ) ( LINE )? )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:148:4: NEWLINE ( SPACE )* ( EXCLM | LINE ) ( LINE )?
            {
            mNEWLINE(); 
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:148:12: ( SPACE )*
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( (LA2_0=='\t'||LA2_0==' ') ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:148:12: SPACE
            	    {
            	    mSPACE(); 

            	    }
            	    break;

            	default :
            	    break loop2;
                }
            } while (true);

            if ( input.LA(1)=='!'||input.LA(1)=='|' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }

            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:148:32: ( LINE )?
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0=='|') ) {
                alt3=1;
            }
            switch (alt3) {
                case 1 :
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:148:32: LINE
                    {
                    mLINE(); 

                    }
                    break;

            }


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end NEWLINECELLBORDERTEXT

    // $ANTLR start COLUMNBREAKBORDERTEXT
    public final void mCOLUMNBREAKBORDERTEXT() throws RecognitionException {
        try {
            int _type = COLUMNBREAKBORDERTEXT;
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:150:2: ( NEWLINE ( SPACE )* ( LINE | EXCLM ) ( MINUS )+ ( SPACE )* )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:150:4: NEWLINE ( SPACE )* ( LINE | EXCLM ) ( MINUS )+ ( SPACE )*
            {
            mNEWLINE(); 
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:150:12: ( SPACE )*
            loop4:
            do {
                int alt4=2;
                int LA4_0 = input.LA(1);

                if ( (LA4_0=='\t'||LA4_0==' ') ) {
                    alt4=1;
                }


                switch (alt4) {
            	case 1 :
            	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:150:12: SPACE
            	    {
            	    mSPACE(); 

            	    }
            	    break;

            	default :
            	    break loop4;
                }
            } while (true);

            if ( input.LA(1)=='!'||input.LA(1)=='|' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }

            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:150:32: ( MINUS )+
            int cnt5=0;
            loop5:
            do {
                int alt5=2;
                int LA5_0 = input.LA(1);

                if ( (LA5_0=='-') ) {
                    alt5=1;
                }


                switch (alt5) {
            	case 1 :
            	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:150:32: MINUS
            	    {
            	    mMINUS(); 

            	    }
            	    break;

            	default :
            	    if ( cnt5 >= 1 ) break loop5;
                        EarlyExitException eee =
                            new EarlyExitException(5, input);
                        throw eee;
                }
                cnt5++;
            } while (true);

            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:150:39: ( SPACE )*
            loop6:
            do {
                int alt6=2;
                int LA6_0 = input.LA(1);

                if ( (LA6_0=='\t'||LA6_0==' ') ) {
                    alt6=1;
                }


                switch (alt6) {
            	case 1 :
            	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:150:39: SPACE
            	    {
            	    mSPACE(); 

            	    }
            	    break;

            	default :
            	    break loop6;
                }
            } while (true);


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end COLUMNBREAKBORDERTEXT

    // $ANTLR start LEXNEWLINE
    public final void mLEXNEWLINE() throws RecognitionException {
        try {
            int _type = LEXNEWLINE;
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:152:2: ( NEWLINE ( SPACE )* )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:152:4: NEWLINE ( SPACE )*
            {
            mNEWLINE(); 
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:152:12: ( SPACE )*
            loop7:
            do {
                int alt7=2;
                int LA7_0 = input.LA(1);

                if ( (LA7_0=='\t'||LA7_0==' ') ) {
                    alt7=1;
                }


                switch (alt7) {
            	case 1 :
            	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:152:12: SPACE
            	    {
            	    mSPACE(); 

            	    }
            	    break;

            	default :
            	    break loop7;
                }
            } while (true);


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end LEXNEWLINE

    // $ANTLR start EXCLM
    public final void mEXCLM() throws RecognitionException {
        try {
            int _type = EXCLM;
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:155:7: ( '!' )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:155:9: '!'
            {
            match('!'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end EXCLM

    // $ANTLR start LINE
    public final void mLINE() throws RecognitionException {
        try {
            int _type = LINE;
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:156:6: ( '|' )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:156:8: '|'
            {
            match('|'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end LINE

    // $ANTLR start NEWLINE
    public final void mNEWLINE() throws RecognitionException {
        try {
            int _type = NEWLINE;
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:157:9: ( ( '\\r' )? '\\n' )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:157:11: ( '\\r' )? '\\n'
            {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:157:11: ( '\\r' )?
            int alt8=2;
            int LA8_0 = input.LA(1);

            if ( (LA8_0=='\r') ) {
                alt8=1;
            }
            switch (alt8) {
                case 1 :
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:157:11: '\\r'
                    {
                    match('\r'); 

                    }
                    break;

            }

            match('\n'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end NEWLINE

    // $ANTLR start SPACE
    public final void mSPACE() throws RecognitionException {
        try {
            int _type = SPACE;
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:158:7: ( ( ' ' | '\\t' ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:158:9: ( ' ' | '\\t' )
            {
            if ( input.LA(1)=='\t'||input.LA(1)==' ' ) {
                input.consume();

            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recover(mse);    throw mse;
            }


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end SPACE

    // $ANTLR start MINUS
    public final void mMINUS() throws RecognitionException {
        try {
            int _type = MINUS;
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:159:7: ( '-' )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:159:9: '-'
            {
            match('-'); 

            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end MINUS

    // $ANTLR start LITERALS
    public final void mLITERALS() throws RecognitionException {
        try {
            int _type = LITERALS;
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:160:9: ( ( '\\u0022' .. '\\u002C' | '\\u002E' .. '\\u007B' | '\\u007D' .. '\\uFFFE' )+ )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:160:11: ( '\\u0022' .. '\\u002C' | '\\u002E' .. '\\u007B' | '\\u007D' .. '\\uFFFE' )+
            {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:160:11: ( '\\u0022' .. '\\u002C' | '\\u002E' .. '\\u007B' | '\\u007D' .. '\\uFFFE' )+
            int cnt9=0;
            loop9:
            do {
                int alt9=2;
                int LA9_0 = input.LA(1);

                if ( ((LA9_0>='\"' && LA9_0<=',')||(LA9_0>='.' && LA9_0<='{')||(LA9_0>='}' && LA9_0<='\uFFFE')) ) {
                    alt9=1;
                }


                switch (alt9) {
            	case 1 :
            	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:
            	    {
            	    if ( (input.LA(1)>='\"' && input.LA(1)<=',')||(input.LA(1)>='.' && input.LA(1)<='{')||(input.LA(1)>='}' && input.LA(1)<='\uFFFE') ) {
            	        input.consume();

            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recover(mse);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt9 >= 1 ) break loop9;
                        EarlyExitException eee =
                            new EarlyExitException(9, input);
                        throw eee;
                }
                cnt9++;
            } while (true);


            }

            this.type = _type;
        }
        finally {
        }
    }
    // $ANTLR end LITERALS

    public void mTokens() throws RecognitionException {
        // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:1:8: ( NEWLINETRIPLELINE | SAMELINECELLBORDERTEXT | NEWLINECELLBORDERTEXT | COLUMNBREAKBORDERTEXT | LEXNEWLINE | EXCLM | LINE | NEWLINE | SPACE | MINUS | LITERALS )
        int alt10=11;
        alt10 = dfa10.predict(input);
        switch (alt10) {
            case 1 :
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:1:10: NEWLINETRIPLELINE
                {
                mNEWLINETRIPLELINE(); 

                }
                break;
            case 2 :
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:1:28: SAMELINECELLBORDERTEXT
                {
                mSAMELINECELLBORDERTEXT(); 

                }
                break;
            case 3 :
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:1:51: NEWLINECELLBORDERTEXT
                {
                mNEWLINECELLBORDERTEXT(); 

                }
                break;
            case 4 :
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:1:73: COLUMNBREAKBORDERTEXT
                {
                mCOLUMNBREAKBORDERTEXT(); 

                }
                break;
            case 5 :
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:1:95: LEXNEWLINE
                {
                mLEXNEWLINE(); 

                }
                break;
            case 6 :
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:1:106: EXCLM
                {
                mEXCLM(); 

                }
                break;
            case 7 :
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:1:112: LINE
                {
                mLINE(); 

                }
                break;
            case 8 :
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:1:117: NEWLINE
                {
                mNEWLINE(); 

                }
                break;
            case 9 :
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:1:125: SPACE
                {
                mSPACE(); 

                }
                break;
            case 10 :
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:1:131: MINUS
                {
                mMINUS(); 

                }
                break;
            case 11 :
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:1:137: LITERALS
                {
                mLITERALS(); 

                }
                break;

        }

    }


    protected DFA10 dfa10 = new DFA10(this);
    static final String DFA10_eotS =
        "\2\uffff\1\10\1\13\5\uffff\1\10\1\17\3\uffff\1\17\2\uffff";
    static final String DFA10_eofS =
        "\21\uffff";
    static final String DFA10_minS =
        "\1\11\1\12\1\11\1\174\5\uffff\1\11\1\55\3\uffff\1\174\2\uffff";
    static final String DFA10_maxS =
        "\1\ufffe\1\12\2\174\5\uffff\2\174\3\uffff\1\174\2\uffff";
    static final String DFA10_acceptS =
        "\4\uffff\1\6\1\11\1\12\1\13\1\5\2\uffff\1\7\1\2\1\4\1\uffff\1\3"+
        "\1\1";
    static final String DFA10_specialS =
        "\21\uffff}>";
    static final String[] DFA10_transitionS = {
            "\1\5\1\2\2\uffff\1\1\22\uffff\1\5\1\4\13\7\1\6\116\7\1\3\uff82"+
            "\7",
            "\1\2",
            "\1\11\26\uffff\1\11\1\12\132\uffff\1\12",
            "\1\14",
            "",
            "",
            "",
            "",
            "",
            "\1\11\26\uffff\1\11\1\12\132\uffff\1\12",
            "\1\15\116\uffff\1\16",
            "",
            "",
            "",
            "\1\20",
            "",
            ""
    };

    static final short[] DFA10_eot = DFA.unpackEncodedString(DFA10_eotS);
    static final short[] DFA10_eof = DFA.unpackEncodedString(DFA10_eofS);
    static final char[] DFA10_min = DFA.unpackEncodedStringToUnsignedChars(DFA10_minS);
    static final char[] DFA10_max = DFA.unpackEncodedStringToUnsignedChars(DFA10_maxS);
    static final short[] DFA10_accept = DFA.unpackEncodedString(DFA10_acceptS);
    static final short[] DFA10_special = DFA.unpackEncodedString(DFA10_specialS);
    static final short[][] DFA10_transition;

    static {
        int numStates = DFA10_transitionS.length;
        DFA10_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA10_transition[i] = DFA.unpackEncodedString(DFA10_transitionS[i]);
        }
    }

    class DFA10 extends DFA {

        public DFA10(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 10;
            this.eot = DFA10_eot;
            this.eof = DFA10_eof;
            this.min = DFA10_min;
            this.max = DFA10_max;
            this.accept = DFA10_accept;
            this.special = DFA10_special;
            this.transition = DFA10_transition;
        }
        public String getDescription() {
            return "1:1: Tokens : ( NEWLINETRIPLELINE | SAMELINECELLBORDERTEXT | NEWLINECELLBORDERTEXT | COLUMNBREAKBORDERTEXT | LEXNEWLINE | EXCLM | LINE | NEWLINE | SPACE | MINUS | LITERALS );";
        }
    }
 

}