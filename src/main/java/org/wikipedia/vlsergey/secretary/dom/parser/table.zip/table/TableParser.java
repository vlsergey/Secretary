// $ANTLR 3.0.1 E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g 2008-03-12 11:55:01

	package org.wikipedia.vlsergey.parser.table;


import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;


import org.antlr.runtime.tree.*;

public class TableParser extends Parser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "TABLEATTRIBUTES", "TABLETAIL", "CELL", "CELLATTRIBUTES", "CELLATTRIBUTESBORDER", "CELLBORDER", "CELLCHILDREN", "COLUMNBREAK", "COLUMNBREAKBORDER", "COLUMNBREAKATTRIBUTES", "COLUMNBREAKTAIL", "LEXNEWLINE", "SPACE", "NEWLINETRIPLELINE", "NEWLINECELLBORDERTEXT", "LINE", "SAMELINECELLBORDERTEXT", "COLUMNBREAKBORDERTEXT", "LITERALS", "EXCLM", "MINUS", "NEWLINE"
    };
    public static final int COLUMNBREAKBORDERTEXT=21;
    public static final int NEWLINECELLBORDERTEXT=18;
    public static final int SAMELINECELLBORDERTEXT=20;
    public static final int COLUMNBREAKBORDER=12;
    public static final int EXCLM=23;
    public static final int CELL=6;
    public static final int COLUMNBREAKATTRIBUTES=13;
    public static final int CELLBORDER=9;
    public static final int MINUS=24;
    public static final int LITERALS=22;
    public static final int CELLATTRIBUTES=7;
    public static final int EOF=-1;
    public static final int SPACE=16;
    public static final int LINE=19;
    public static final int CELLATTRIBUTESBORDER=8;
    public static final int TABLETAIL=5;
    public static final int NEWLINE=25;
    public static final int LEXNEWLINE=15;
    public static final int NEWLINETRIPLELINE=17;
    public static final int TABLEATTRIBUTES=4;
    public static final int COLUMNBREAKTAIL=14;
    public static final int CELLCHILDREN=10;
    public static final int COLUMNBREAK=11;

        public TableParser(TokenStream input) {
            super(input);
        }
        
    protected TreeAdaptor adaptor = new CommonTreeAdaptor();

    public void setTreeAdaptor(TreeAdaptor adaptor) {
        this.adaptor = adaptor;
    }
    public TreeAdaptor getTreeAdaptor() {
        return adaptor;
    }

    public String[] getTokenNames() { return tokenNames; }
    public String getGrammarFileName() { return "E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g"; }

    
    	@Override
    	public void reportError(RecognitionException exc) {
    		String header = getErrorHeader(exc);
    		String message = getErrorMessage(exc, getTokenNames());
    		String strExc = header + " " + message + " (" + exc.getMessage() + ")";
    		throw new org.wikipedia.vlsergey.parser.ParsingException(strExc, exc);
    	}


    public static class table_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start table
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:50:1: table : ( tableattributes )? ( cellsline )+ tabletail EOF ;
    public final table_return table() throws RecognitionException {
        table_return retval = new table_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token EOF4=null;
        tableattributes_return tableattributes1 = null;

        cellsline_return cellsline2 = null;

        tabletail_return tabletail3 = null;


        CommonTree EOF4_tree=null;

        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:50:7: ( ( tableattributes )? ( cellsline )+ tabletail EOF )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:50:9: ( tableattributes )? ( cellsline )+ tabletail EOF
            {
            root_0 = (CommonTree)adaptor.nil();

            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:50:9: ( tableattributes )?
            int alt1=2;
            int LA1_0 = input.LA(1);

            if ( (LA1_0==SPACE||LA1_0==LITERALS) ) {
                alt1=1;
            }
            switch (alt1) {
                case 1 :
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:50:9: tableattributes
                    {
                    pushFollow(FOLLOW_tableattributes_in_table103);
                    tableattributes1=tableattributes();
                    _fsp--;

                    adaptor.addChild(root_0, tableattributes1.getTree());

                    }
                    break;

            }

            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:50:26: ( cellsline )+
            int cnt2=0;
            loop2:
            do {
                int alt2=2;
                int LA2_0 = input.LA(1);

                if ( ((LA2_0>=NEWLINETRIPLELINE && LA2_0<=NEWLINECELLBORDERTEXT)||LA2_0==COLUMNBREAKBORDERTEXT) ) {
                    alt2=1;
                }


                switch (alt2) {
            	case 1 :
            	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:50:26: cellsline
            	    {
            	    pushFollow(FOLLOW_cellsline_in_table106);
            	    cellsline2=cellsline();
            	    _fsp--;

            	    adaptor.addChild(root_0, cellsline2.getTree());

            	    }
            	    break;

            	default :
            	    if ( cnt2 >= 1 ) break loop2;
                        EarlyExitException eee =
                            new EarlyExitException(2, input);
                        throw eee;
                }
                cnt2++;
            } while (true);

            pushFollow(FOLLOW_tabletail_in_table109);
            tabletail3=tabletail();
            _fsp--;

            adaptor.addChild(root_0, tabletail3.getTree());
            EOF4=(Token)input.LT(1);
            match(input,EOF,FOLLOW_EOF_in_table111); 

            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end table

    public static class tableattributes_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start tableattributes
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:52:1: tableattributes : attributestext -> ^( TABLEATTRIBUTES[$text] attributestext ) ;
    public final tableattributes_return tableattributes() throws RecognitionException {
        tableattributes_return retval = new tableattributes_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        attributestext_return attributestext5 = null;


        RewriteRuleSubtreeStream stream_attributestext=new RewriteRuleSubtreeStream(adaptor,"rule attributestext");
        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:53:2: ( attributestext -> ^( TABLEATTRIBUTES[$text] attributestext ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:53:4: attributestext
            {
            pushFollow(FOLLOW_attributestext_in_tableattributes121);
            attributestext5=attributestext();
            _fsp--;

            stream_attributestext.add(attributestext5.getTree());

            // AST REWRITE
            // elements: attributestext
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 54:3: -> ^( TABLEATTRIBUTES[$text] attributestext )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:55:3: ^( TABLEATTRIBUTES[$text] attributestext )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(TABLEATTRIBUTES, input.toString(retval.start,input.LT(-1))), root_1);

                adaptor.addChild(root_1, stream_attributestext.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end tableattributes

    public static class tabletail_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start tabletail
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:57:1: tabletail : tabletailtext -> ^( TABLETAIL[$text] tabletailtext ) ;
    public final tabletail_return tabletail() throws RecognitionException {
        tabletail_return retval = new tabletail_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        tabletailtext_return tabletailtext6 = null;


        RewriteRuleSubtreeStream stream_tabletailtext=new RewriteRuleSubtreeStream(adaptor,"rule tabletailtext");
        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:58:2: ( tabletailtext -> ^( TABLETAIL[$text] tabletailtext ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:58:4: tabletailtext
            {
            pushFollow(FOLLOW_tabletailtext_in_tabletail143);
            tabletailtext6=tabletailtext();
            _fsp--;

            stream_tabletailtext.add(tabletailtext6.getTree());

            // AST REWRITE
            // elements: tabletailtext
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 59:3: -> ^( TABLETAIL[$text] tabletailtext )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:60:3: ^( TABLETAIL[$text] tabletailtext )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(TABLETAIL, input.toString(retval.start,input.LT(-1))), root_1);

                adaptor.addChild(root_1, stream_tabletailtext.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end tabletail

    public static class tabletailtext_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start tabletailtext
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:62:1: tabletailtext : ( LEXNEWLINE | SPACE )* ;
    public final tabletailtext_return tabletailtext() throws RecognitionException {
        tabletailtext_return retval = new tabletailtext_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set7=null;

        CommonTree set7_tree=null;

        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:63:2: ( ( LEXNEWLINE | SPACE )* )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:63:4: ( LEXNEWLINE | SPACE )*
            {
            root_0 = (CommonTree)adaptor.nil();

            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:63:4: ( LEXNEWLINE | SPACE )*
            loop3:
            do {
                int alt3=2;
                int LA3_0 = input.LA(1);

                if ( ((LA3_0>=LEXNEWLINE && LA3_0<=SPACE)) ) {
                    alt3=1;
                }


                switch (alt3) {
            	case 1 :
            	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:
            	    {
            	    set7=(Token)input.LT(1);
            	    if ( (input.LA(1)>=LEXNEWLINE && input.LA(1)<=SPACE) ) {
            	        input.consume();
            	        adaptor.addChild(root_0, adaptor.create(set7));
            	        errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_tabletailtext165);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop3;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end tabletailtext

    public static class cellsline_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start cellsline
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:65:1: cellsline : ( columnbreak | ( ( newlinecell | newemptydouble ) ( samelinecell )* ) );
    public final cellsline_return cellsline() throws RecognitionException {
        cellsline_return retval = new cellsline_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        columnbreak_return columnbreak8 = null;

        newlinecell_return newlinecell9 = null;

        newemptydouble_return newemptydouble10 = null;

        samelinecell_return samelinecell11 = null;



        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:66:2: ( columnbreak | ( ( newlinecell | newemptydouble ) ( samelinecell )* ) )
            int alt6=2;
            int LA6_0 = input.LA(1);

            if ( (LA6_0==COLUMNBREAKBORDERTEXT) ) {
                alt6=1;
            }
            else if ( ((LA6_0>=NEWLINETRIPLELINE && LA6_0<=NEWLINECELLBORDERTEXT)) ) {
                alt6=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("65:1: cellsline : ( columnbreak | ( ( newlinecell | newemptydouble ) ( samelinecell )* ) );", 6, 0, input);

                throw nvae;
            }
            switch (alt6) {
                case 1 :
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:66:4: columnbreak
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    pushFollow(FOLLOW_columnbreak_in_cellsline179);
                    columnbreak8=columnbreak();
                    _fsp--;

                    adaptor.addChild(root_0, columnbreak8.getTree());

                    }
                    break;
                case 2 :
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:66:16: ( ( newlinecell | newemptydouble ) ( samelinecell )* )
                    {
                    root_0 = (CommonTree)adaptor.nil();

                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:66:16: ( ( newlinecell | newemptydouble ) ( samelinecell )* )
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:66:17: ( newlinecell | newemptydouble ) ( samelinecell )*
                    {
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:66:17: ( newlinecell | newemptydouble )
                    int alt4=2;
                    int LA4_0 = input.LA(1);

                    if ( (LA4_0==NEWLINECELLBORDERTEXT) ) {
                        alt4=1;
                    }
                    else if ( (LA4_0==NEWLINETRIPLELINE) ) {
                        alt4=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("66:17: ( newlinecell | newemptydouble )", 4, 0, input);

                        throw nvae;
                    }
                    switch (alt4) {
                        case 1 :
                            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:66:18: newlinecell
                            {
                            pushFollow(FOLLOW_newlinecell_in_cellsline183);
                            newlinecell9=newlinecell();
                            _fsp--;

                            adaptor.addChild(root_0, newlinecell9.getTree());

                            }
                            break;
                        case 2 :
                            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:66:30: newemptydouble
                            {
                            pushFollow(FOLLOW_newemptydouble_in_cellsline185);
                            newemptydouble10=newemptydouble();
                            _fsp--;

                            adaptor.addChild(root_0, newemptydouble10.getTree());

                            }
                            break;

                    }

                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:66:46: ( samelinecell )*
                    loop5:
                    do {
                        int alt5=2;
                        int LA5_0 = input.LA(1);

                        if ( (LA5_0==SAMELINECELLBORDERTEXT) ) {
                            alt5=1;
                        }


                        switch (alt5) {
                    	case 1 :
                    	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:66:46: samelinecell
                    	    {
                    	    pushFollow(FOLLOW_samelinecell_in_cellsline188);
                    	    samelinecell11=samelinecell();
                    	    _fsp--;

                    	    adaptor.addChild(root_0, samelinecell11.getTree());

                    	    }
                    	    break;

                    	default :
                    	    break loop5;
                        }
                    } while (true);


                    }


                    }
                    break;

            }
            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end cellsline

    public static class newlinecell_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start newlinecell
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:68:1: newlinecell : newlinecellborder ( cellattributes cellattributesborder )? cellchildren -> ^( CELL[$text] newlinecellborder ( cellattributes cellattributesborder )? cellchildren ) ;
    public final newlinecell_return newlinecell() throws RecognitionException {
        newlinecell_return retval = new newlinecell_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        newlinecellborder_return newlinecellborder12 = null;

        cellattributes_return cellattributes13 = null;

        cellattributesborder_return cellattributesborder14 = null;

        cellchildren_return cellchildren15 = null;


        RewriteRuleSubtreeStream stream_cellchildren=new RewriteRuleSubtreeStream(adaptor,"rule cellchildren");
        RewriteRuleSubtreeStream stream_cellattributes=new RewriteRuleSubtreeStream(adaptor,"rule cellattributes");
        RewriteRuleSubtreeStream stream_newlinecellborder=new RewriteRuleSubtreeStream(adaptor,"rule newlinecellborder");
        RewriteRuleSubtreeStream stream_cellattributesborder=new RewriteRuleSubtreeStream(adaptor,"rule cellattributesborder");
        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:69:2: ( newlinecellborder ( cellattributes cellattributesborder )? cellchildren -> ^( CELL[$text] newlinecellborder ( cellattributes cellattributesborder )? cellchildren ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:69:4: newlinecellborder ( cellattributes cellattributesborder )? cellchildren
            {
            pushFollow(FOLLOW_newlinecellborder_in_newlinecell199);
            newlinecellborder12=newlinecellborder();
            _fsp--;

            stream_newlinecellborder.add(newlinecellborder12.getTree());
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:69:22: ( cellattributes cellattributesborder )?
            int alt7=2;
            alt7 = dfa7.predict(input);
            switch (alt7) {
                case 1 :
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:69:23: cellattributes cellattributesborder
                    {
                    pushFollow(FOLLOW_cellattributes_in_newlinecell202);
                    cellattributes13=cellattributes();
                    _fsp--;

                    stream_cellattributes.add(cellattributes13.getTree());
                    pushFollow(FOLLOW_cellattributesborder_in_newlinecell204);
                    cellattributesborder14=cellattributesborder();
                    _fsp--;

                    stream_cellattributesborder.add(cellattributesborder14.getTree());

                    }
                    break;

            }

            pushFollow(FOLLOW_cellchildren_in_newlinecell208);
            cellchildren15=cellchildren();
            _fsp--;

            stream_cellchildren.add(cellchildren15.getTree());

            // AST REWRITE
            // elements: cellattributes, newlinecellborder, cellattributesborder, cellchildren
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 70:3: -> ^( CELL[$text] newlinecellborder ( cellattributes cellattributesborder )? cellchildren )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:71:3: ^( CELL[$text] newlinecellborder ( cellattributes cellattributesborder )? cellchildren )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(CELL, input.toString(retval.start,input.LT(-1))), root_1);

                adaptor.addChild(root_1, stream_newlinecellborder.next());
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:71:35: ( cellattributes cellattributesborder )?
                if ( stream_cellattributes.hasNext()||stream_cellattributesborder.hasNext() ) {
                    adaptor.addChild(root_1, stream_cellattributes.next());
                    adaptor.addChild(root_1, stream_cellattributesborder.next());

                }
                stream_cellattributes.reset();
                stream_cellattributesborder.reset();
                adaptor.addChild(root_1, stream_cellchildren.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end newlinecell

    public static class newemptydouble_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start newemptydouble
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:73:1: newemptydouble : newemptydoubleborder ( cellattributes cellattributesborder )? cellchildren -> ^( CELL[Tools.substringBeforeDouble(1,$newemptydoubleborder.text,1)] CELLBORDER[Tools.substringBeforeDouble(1,$newemptydoubleborder.text,1)] ) ^( CELL[Tools.substringAfterDouble(1,$text,1)] CELLBORDER[\"||\"] ( cellattributes cellattributesborder )? cellchildren ) ;
    public final newemptydouble_return newemptydouble() throws RecognitionException {
        newemptydouble_return retval = new newemptydouble_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        newemptydoubleborder_return newemptydoubleborder16 = null;

        cellattributes_return cellattributes17 = null;

        cellattributesborder_return cellattributesborder18 = null;

        cellchildren_return cellchildren19 = null;


        RewriteRuleSubtreeStream stream_newemptydoubleborder=new RewriteRuleSubtreeStream(adaptor,"rule newemptydoubleborder");
        RewriteRuleSubtreeStream stream_cellchildren=new RewriteRuleSubtreeStream(adaptor,"rule cellchildren");
        RewriteRuleSubtreeStream stream_cellattributes=new RewriteRuleSubtreeStream(adaptor,"rule cellattributes");
        RewriteRuleSubtreeStream stream_cellattributesborder=new RewriteRuleSubtreeStream(adaptor,"rule cellattributesborder");
        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:74:2: ( newemptydoubleborder ( cellattributes cellattributesborder )? cellchildren -> ^( CELL[Tools.substringBeforeDouble(1,$newemptydoubleborder.text,1)] CELLBORDER[Tools.substringBeforeDouble(1,$newemptydoubleborder.text,1)] ) ^( CELL[Tools.substringAfterDouble(1,$text,1)] CELLBORDER[\"||\"] ( cellattributes cellattributesborder )? cellchildren ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:74:4: newemptydoubleborder ( cellattributes cellattributesborder )? cellchildren
            {
            pushFollow(FOLLOW_newemptydoubleborder_in_newemptydouble240);
            newemptydoubleborder16=newemptydoubleborder();
            _fsp--;

            stream_newemptydoubleborder.add(newemptydoubleborder16.getTree());
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:74:25: ( cellattributes cellattributesborder )?
            int alt8=2;
            alt8 = dfa8.predict(input);
            switch (alt8) {
                case 1 :
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:74:26: cellattributes cellattributesborder
                    {
                    pushFollow(FOLLOW_cellattributes_in_newemptydouble243);
                    cellattributes17=cellattributes();
                    _fsp--;

                    stream_cellattributes.add(cellattributes17.getTree());
                    pushFollow(FOLLOW_cellattributesborder_in_newemptydouble245);
                    cellattributesborder18=cellattributesborder();
                    _fsp--;

                    stream_cellattributesborder.add(cellattributesborder18.getTree());

                    }
                    break;

            }

            pushFollow(FOLLOW_cellchildren_in_newemptydouble249);
            cellchildren19=cellchildren();
            _fsp--;

            stream_cellchildren.add(cellchildren19.getTree());

            // AST REWRITE
            // elements: cellattributes, cellattributesborder, cellchildren
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 75:3: -> ^( CELL[Tools.substringBeforeDouble(1,$newemptydoubleborder.text,1)] CELLBORDER[Tools.substringBeforeDouble(1,$newemptydoubleborder.text,1)] ) ^( CELL[Tools.substringAfterDouble(1,$text,1)] CELLBORDER[\"||\"] ( cellattributes cellattributesborder )? cellchildren )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:75:6: ^( CELL[Tools.substringBeforeDouble(1,$newemptydoubleborder.text,1)] CELLBORDER[Tools.substringBeforeDouble(1,$newemptydoubleborder.text,1)] )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(CELL, Tools.substringBeforeDouble(1, input.toString(newemptydoubleborder16.start,newemptydoubleborder16.stop), 1)), root_1);

                adaptor.addChild(root_1, adaptor.create(CELLBORDER, Tools.substringBeforeDouble(1, input.toString(newemptydoubleborder16.start,newemptydoubleborder16.stop), 1)));

                adaptor.addChild(root_0, root_1);
                }
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:76:4: ^( CELL[Tools.substringAfterDouble(1,$text,1)] CELLBORDER[\"||\"] ( cellattributes cellattributesborder )? cellchildren )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(CELL, Tools.substringAfterDouble(1, input.toString(retval.start,input.LT(-1)), 1)), root_1);

                adaptor.addChild(root_1, adaptor.create(CELLBORDER, "||"));
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:76:67: ( cellattributes cellattributesborder )?
                if ( stream_cellattributes.hasNext()||stream_cellattributesborder.hasNext() ) {
                    adaptor.addChild(root_1, stream_cellattributes.next());
                    adaptor.addChild(root_1, stream_cellattributesborder.next());

                }
                stream_cellattributes.reset();
                stream_cellattributesborder.reset();
                adaptor.addChild(root_1, stream_cellchildren.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end newemptydouble

    public static class newemptydoubleborder_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start newemptydoubleborder
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:77:1: newemptydoubleborder : NEWLINETRIPLELINE ;
    public final newemptydoubleborder_return newemptydoubleborder() throws RecognitionException {
        newemptydoubleborder_return retval = new newemptydoubleborder_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token NEWLINETRIPLELINE20=null;

        CommonTree NEWLINETRIPLELINE20_tree=null;

        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:78:2: ( NEWLINETRIPLELINE )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:78:4: NEWLINETRIPLELINE
            {
            root_0 = (CommonTree)adaptor.nil();

            NEWLINETRIPLELINE20=(Token)input.LT(1);
            match(input,NEWLINETRIPLELINE,FOLLOW_NEWLINETRIPLELINE_in_newemptydoubleborder289); 
            NEWLINETRIPLELINE20_tree = (CommonTree)adaptor.create(NEWLINETRIPLELINE20);
            adaptor.addChild(root_0, NEWLINETRIPLELINE20_tree);


            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end newemptydoubleborder

    public static class cellchildren_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start cellchildren
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:80:1: cellchildren : ( freetext )? -> ^( CELLCHILDREN[$text] ( freetext )? ) ;
    public final cellchildren_return cellchildren() throws RecognitionException {
        cellchildren_return retval = new cellchildren_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        freetext_return freetext21 = null;


        RewriteRuleSubtreeStream stream_freetext=new RewriteRuleSubtreeStream(adaptor,"rule freetext");
        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:81:2: ( ( freetext )? -> ^( CELLCHILDREN[$text] ( freetext )? ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:81:4: ( freetext )?
            {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:81:4: ( freetext )?
            int alt9=2;
            int LA9_0 = input.LA(1);

            if ( ((LA9_0>=LEXNEWLINE && LA9_0<=SPACE)||(LA9_0>=LITERALS && LA9_0<=MINUS)) ) {
                alt9=1;
            }
            switch (alt9) {
                case 1 :
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:81:4: freetext
                    {
                    pushFollow(FOLLOW_freetext_in_cellchildren298);
                    freetext21=freetext();
                    _fsp--;

                    stream_freetext.add(freetext21.getTree());

                    }
                    break;

            }


            // AST REWRITE
            // elements: freetext
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 82:3: -> ^( CELLCHILDREN[$text] ( freetext )? )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:83:3: ^( CELLCHILDREN[$text] ( freetext )? )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(CELLCHILDREN, input.toString(retval.start,input.LT(-1))), root_1);

                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:83:25: ( freetext )?
                if ( stream_freetext.hasNext() ) {
                    adaptor.addChild(root_1, stream_freetext.next());

                }
                stream_freetext.reset();

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end cellchildren

    public static class newlinecellborder_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start newlinecellborder
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:85:1: newlinecellborder : NEWLINECELLBORDERTEXT -> ^( CELLBORDER[$text] NEWLINECELLBORDERTEXT ) ;
    public final newlinecellborder_return newlinecellborder() throws RecognitionException {
        newlinecellborder_return retval = new newlinecellborder_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token NEWLINECELLBORDERTEXT22=null;

        CommonTree NEWLINECELLBORDERTEXT22_tree=null;
        RewriteRuleTokenStream stream_NEWLINECELLBORDERTEXT=new RewriteRuleTokenStream(adaptor,"token NEWLINECELLBORDERTEXT");

        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:86:2: ( NEWLINECELLBORDERTEXT -> ^( CELLBORDER[$text] NEWLINECELLBORDERTEXT ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:86:4: NEWLINECELLBORDERTEXT
            {
            NEWLINECELLBORDERTEXT22=(Token)input.LT(1);
            match(input,NEWLINECELLBORDERTEXT,FOLLOW_NEWLINECELLBORDERTEXT_in_newlinecellborder322); 
            stream_NEWLINECELLBORDERTEXT.add(NEWLINECELLBORDERTEXT22);


            // AST REWRITE
            // elements: NEWLINECELLBORDERTEXT
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 87:3: -> ^( CELLBORDER[$text] NEWLINECELLBORDERTEXT )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:88:3: ^( CELLBORDER[$text] NEWLINECELLBORDERTEXT )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(CELLBORDER, input.toString(retval.start,input.LT(-1))), root_1);

                adaptor.addChild(root_1, stream_NEWLINECELLBORDERTEXT.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end newlinecellborder

    public static class cellattributes_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start cellattributes
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:91:1: cellattributes : attributestext -> ^( CELLATTRIBUTES[$text] attributestext ) ;
    public final cellattributes_return cellattributes() throws RecognitionException {
        cellattributes_return retval = new cellattributes_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        attributestext_return attributestext23 = null;


        RewriteRuleSubtreeStream stream_attributestext=new RewriteRuleSubtreeStream(adaptor,"rule attributestext");
        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:92:2: ( attributestext -> ^( CELLATTRIBUTES[$text] attributestext ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:92:4: attributestext
            {
            pushFollow(FOLLOW_attributestext_in_cellattributes345);
            attributestext23=attributestext();
            _fsp--;

            stream_attributestext.add(attributestext23.getTree());

            // AST REWRITE
            // elements: attributestext
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 93:3: -> ^( CELLATTRIBUTES[$text] attributestext )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:94:3: ^( CELLATTRIBUTES[$text] attributestext )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(CELLATTRIBUTES, input.toString(retval.start,input.LT(-1))), root_1);

                adaptor.addChild(root_1, stream_attributestext.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end cellattributes

    public static class cellattributesborder_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start cellattributesborder
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:96:1: cellattributesborder : LINE -> ^( CELLATTRIBUTESBORDER[$text] LINE ) ;
    public final cellattributesborder_return cellattributesborder() throws RecognitionException {
        cellattributesborder_return retval = new cellattributesborder_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token LINE24=null;

        CommonTree LINE24_tree=null;
        RewriteRuleTokenStream stream_LINE=new RewriteRuleTokenStream(adaptor,"token LINE");

        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:97:2: ( LINE -> ^( CELLATTRIBUTESBORDER[$text] LINE ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:97:4: LINE
            {
            LINE24=(Token)input.LT(1);
            match(input,LINE,FOLLOW_LINE_in_cellattributesborder367); 
            stream_LINE.add(LINE24);


            // AST REWRITE
            // elements: LINE
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 98:3: -> ^( CELLATTRIBUTESBORDER[$text] LINE )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:99:3: ^( CELLATTRIBUTESBORDER[$text] LINE )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(CELLATTRIBUTESBORDER, input.toString(retval.start,input.LT(-1))), root_1);

                adaptor.addChild(root_1, stream_LINE.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end cellattributesborder

    public static class samelinecell_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start samelinecell
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:101:1: samelinecell : samelinecellborder ( cellattributes cellattributesborder )? cellchildren -> ^( CELL[$text] samelinecellborder ( cellattributes cellattributesborder )? cellchildren ) ;
    public final samelinecell_return samelinecell() throws RecognitionException {
        samelinecell_return retval = new samelinecell_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        samelinecellborder_return samelinecellborder25 = null;

        cellattributes_return cellattributes26 = null;

        cellattributesborder_return cellattributesborder27 = null;

        cellchildren_return cellchildren28 = null;


        RewriteRuleSubtreeStream stream_cellchildren=new RewriteRuleSubtreeStream(adaptor,"rule cellchildren");
        RewriteRuleSubtreeStream stream_cellattributes=new RewriteRuleSubtreeStream(adaptor,"rule cellattributes");
        RewriteRuleSubtreeStream stream_cellattributesborder=new RewriteRuleSubtreeStream(adaptor,"rule cellattributesborder");
        RewriteRuleSubtreeStream stream_samelinecellborder=new RewriteRuleSubtreeStream(adaptor,"rule samelinecellborder");
        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:102:2: ( samelinecellborder ( cellattributes cellattributesborder )? cellchildren -> ^( CELL[$text] samelinecellborder ( cellattributes cellattributesborder )? cellchildren ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:102:4: samelinecellborder ( cellattributes cellattributesborder )? cellchildren
            {
            pushFollow(FOLLOW_samelinecellborder_in_samelinecell389);
            samelinecellborder25=samelinecellborder();
            _fsp--;

            stream_samelinecellborder.add(samelinecellborder25.getTree());
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:102:23: ( cellattributes cellattributesborder )?
            int alt10=2;
            alt10 = dfa10.predict(input);
            switch (alt10) {
                case 1 :
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:102:24: cellattributes cellattributesborder
                    {
                    pushFollow(FOLLOW_cellattributes_in_samelinecell392);
                    cellattributes26=cellattributes();
                    _fsp--;

                    stream_cellattributes.add(cellattributes26.getTree());
                    pushFollow(FOLLOW_cellattributesborder_in_samelinecell394);
                    cellattributesborder27=cellattributesborder();
                    _fsp--;

                    stream_cellattributesborder.add(cellattributesborder27.getTree());

                    }
                    break;

            }

            pushFollow(FOLLOW_cellchildren_in_samelinecell398);
            cellchildren28=cellchildren();
            _fsp--;

            stream_cellchildren.add(cellchildren28.getTree());

            // AST REWRITE
            // elements: samelinecellborder, cellchildren, cellattributesborder, cellattributes
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 103:3: -> ^( CELL[$text] samelinecellborder ( cellattributes cellattributesborder )? cellchildren )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:104:3: ^( CELL[$text] samelinecellborder ( cellattributes cellattributesborder )? cellchildren )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(CELL, input.toString(retval.start,input.LT(-1))), root_1);

                adaptor.addChild(root_1, stream_samelinecellborder.next());
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:104:36: ( cellattributes cellattributesborder )?
                if ( stream_cellattributesborder.hasNext()||stream_cellattributes.hasNext() ) {
                    adaptor.addChild(root_1, stream_cellattributes.next());
                    adaptor.addChild(root_1, stream_cellattributesborder.next());

                }
                stream_cellattributesborder.reset();
                stream_cellattributes.reset();
                adaptor.addChild(root_1, stream_cellchildren.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end samelinecell

    public static class samelinecellborder_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start samelinecellborder
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:106:1: samelinecellborder : SAMELINECELLBORDERTEXT -> ^( CELLBORDER[$text] SAMELINECELLBORDERTEXT ) ;
    public final samelinecellborder_return samelinecellborder() throws RecognitionException {
        samelinecellborder_return retval = new samelinecellborder_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token SAMELINECELLBORDERTEXT29=null;

        CommonTree SAMELINECELLBORDERTEXT29_tree=null;
        RewriteRuleTokenStream stream_SAMELINECELLBORDERTEXT=new RewriteRuleTokenStream(adaptor,"token SAMELINECELLBORDERTEXT");

        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:107:2: ( SAMELINECELLBORDERTEXT -> ^( CELLBORDER[$text] SAMELINECELLBORDERTEXT ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:107:4: SAMELINECELLBORDERTEXT
            {
            SAMELINECELLBORDERTEXT29=(Token)input.LT(1);
            match(input,SAMELINECELLBORDERTEXT,FOLLOW_SAMELINECELLBORDERTEXT_in_samelinecellborder430); 
            stream_SAMELINECELLBORDERTEXT.add(SAMELINECELLBORDERTEXT29);


            // AST REWRITE
            // elements: SAMELINECELLBORDERTEXT
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 108:3: -> ^( CELLBORDER[$text] SAMELINECELLBORDERTEXT )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:108:6: ^( CELLBORDER[$text] SAMELINECELLBORDERTEXT )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(CELLBORDER, input.toString(retval.start,input.LT(-1))), root_1);

                adaptor.addChild(root_1, stream_SAMELINECELLBORDERTEXT.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end samelinecellborder

    public static class columnbreak_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start columnbreak
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:111:1: columnbreak : columnbreaktext -> ^( COLUMNBREAK[$text] columnbreaktext ) ;
    public final columnbreak_return columnbreak() throws RecognitionException {
        columnbreak_return retval = new columnbreak_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        columnbreaktext_return columnbreaktext30 = null;


        RewriteRuleSubtreeStream stream_columnbreaktext=new RewriteRuleSubtreeStream(adaptor,"rule columnbreaktext");
        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:112:2: ( columnbreaktext -> ^( COLUMNBREAK[$text] columnbreaktext ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:112:4: columnbreaktext
            {
            pushFollow(FOLLOW_columnbreaktext_in_columnbreak451);
            columnbreaktext30=columnbreaktext();
            _fsp--;

            stream_columnbreaktext.add(columnbreaktext30.getTree());

            // AST REWRITE
            // elements: columnbreaktext
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 113:3: -> ^( COLUMNBREAK[$text] columnbreaktext )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:113:6: ^( COLUMNBREAK[$text] columnbreaktext )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(COLUMNBREAK, input.toString(retval.start,input.LT(-1))), root_1);

                adaptor.addChild(root_1, stream_columnbreaktext.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end columnbreak

    public static class columnbreaktext_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start columnbreaktext
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:115:1: columnbreaktext : columnbreakborder ( columnbreakattributes | columnbreaktail )? ;
    public final columnbreaktext_return columnbreaktext() throws RecognitionException {
        columnbreaktext_return retval = new columnbreaktext_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        columnbreakborder_return columnbreakborder31 = null;

        columnbreakattributes_return columnbreakattributes32 = null;

        columnbreaktail_return columnbreaktail33 = null;



        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:116:2: ( columnbreakborder ( columnbreakattributes | columnbreaktail )? )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:116:4: columnbreakborder ( columnbreakattributes | columnbreaktail )?
            {
            root_0 = (CommonTree)adaptor.nil();

            pushFollow(FOLLOW_columnbreakborder_in_columnbreaktext471);
            columnbreakborder31=columnbreakborder();
            _fsp--;

            adaptor.addChild(root_0, columnbreakborder31.getTree());
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:116:22: ( columnbreakattributes | columnbreaktail )?
            int alt11=3;
            int LA11_0 = input.LA(1);

            if ( (LA11_0==SPACE||LA11_0==LITERALS) ) {
                alt11=1;
            }
            else if ( (LA11_0==LEXNEWLINE) ) {
                alt11=2;
            }
            switch (alt11) {
                case 1 :
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:116:23: columnbreakattributes
                    {
                    pushFollow(FOLLOW_columnbreakattributes_in_columnbreaktext474);
                    columnbreakattributes32=columnbreakattributes();
                    _fsp--;

                    adaptor.addChild(root_0, columnbreakattributes32.getTree());

                    }
                    break;
                case 2 :
                    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:116:45: columnbreaktail
                    {
                    pushFollow(FOLLOW_columnbreaktail_in_columnbreaktext476);
                    columnbreaktail33=columnbreaktail();
                    _fsp--;

                    adaptor.addChild(root_0, columnbreaktail33.getTree());

                    }
                    break;

            }


            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end columnbreaktext

    public static class columnbreakborder_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start columnbreakborder
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:118:1: columnbreakborder : COLUMNBREAKBORDERTEXT -> ^( COLUMNBREAKBORDER[$text] COLUMNBREAKBORDERTEXT ) ;
    public final columnbreakborder_return columnbreakborder() throws RecognitionException {
        columnbreakborder_return retval = new columnbreakborder_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token COLUMNBREAKBORDERTEXT34=null;

        CommonTree COLUMNBREAKBORDERTEXT34_tree=null;
        RewriteRuleTokenStream stream_COLUMNBREAKBORDERTEXT=new RewriteRuleTokenStream(adaptor,"token COLUMNBREAKBORDERTEXT");

        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:119:2: ( COLUMNBREAKBORDERTEXT -> ^( COLUMNBREAKBORDER[$text] COLUMNBREAKBORDERTEXT ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:119:4: COLUMNBREAKBORDERTEXT
            {
            COLUMNBREAKBORDERTEXT34=(Token)input.LT(1);
            match(input,COLUMNBREAKBORDERTEXT,FOLLOW_COLUMNBREAKBORDERTEXT_in_columnbreakborder487); 
            stream_COLUMNBREAKBORDERTEXT.add(COLUMNBREAKBORDERTEXT34);


            // AST REWRITE
            // elements: COLUMNBREAKBORDERTEXT
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 120:3: -> ^( COLUMNBREAKBORDER[$text] COLUMNBREAKBORDERTEXT )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:121:3: ^( COLUMNBREAKBORDER[$text] COLUMNBREAKBORDERTEXT )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(COLUMNBREAKBORDER, input.toString(retval.start,input.LT(-1))), root_1);

                adaptor.addChild(root_1, stream_COLUMNBREAKBORDERTEXT.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end columnbreakborder

    public static class columnbreakattributes_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start columnbreakattributes
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:123:1: columnbreakattributes : attributestext -> ^( COLUMNBREAKATTRIBUTES[$text] attributestext ) ;
    public final columnbreakattributes_return columnbreakattributes() throws RecognitionException {
        columnbreakattributes_return retval = new columnbreakattributes_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        attributestext_return attributestext35 = null;


        RewriteRuleSubtreeStream stream_attributestext=new RewriteRuleSubtreeStream(adaptor,"rule attributestext");
        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:124:2: ( attributestext -> ^( COLUMNBREAKATTRIBUTES[$text] attributestext ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:124:4: attributestext
            {
            pushFollow(FOLLOW_attributestext_in_columnbreakattributes509);
            attributestext35=attributestext();
            _fsp--;

            stream_attributestext.add(attributestext35.getTree());

            // AST REWRITE
            // elements: attributestext
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 125:3: -> ^( COLUMNBREAKATTRIBUTES[$text] attributestext )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:126:3: ^( COLUMNBREAKATTRIBUTES[$text] attributestext )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(COLUMNBREAKATTRIBUTES, input.toString(retval.start,input.LT(-1))), root_1);

                adaptor.addChild(root_1, stream_attributestext.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end columnbreakattributes

    public static class columnbreaktail_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start columnbreaktail
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:128:1: columnbreaktail : columnbreaktailtext -> ^( COLUMNBREAKTAIL[$text] columnbreaktailtext ) ;
    public final columnbreaktail_return columnbreaktail() throws RecognitionException {
        columnbreaktail_return retval = new columnbreaktail_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        columnbreaktailtext_return columnbreaktailtext36 = null;


        RewriteRuleSubtreeStream stream_columnbreaktailtext=new RewriteRuleSubtreeStream(adaptor,"rule columnbreaktailtext");
        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:129:2: ( columnbreaktailtext -> ^( COLUMNBREAKTAIL[$text] columnbreaktailtext ) )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:129:4: columnbreaktailtext
            {
            pushFollow(FOLLOW_columnbreaktailtext_in_columnbreaktail531);
            columnbreaktailtext36=columnbreaktailtext();
            _fsp--;

            stream_columnbreaktailtext.add(columnbreaktailtext36.getTree());

            // AST REWRITE
            // elements: columnbreaktailtext
            // token labels: 
            // rule labels: retval
            // token list labels: 
            // rule list labels: 
            retval.tree = root_0;
            RewriteRuleSubtreeStream stream_retval=new RewriteRuleSubtreeStream(adaptor,"token retval",retval!=null?retval.tree:null);

            root_0 = (CommonTree)adaptor.nil();
            // 130:3: -> ^( COLUMNBREAKTAIL[$text] columnbreaktailtext )
            {
                // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:131:3: ^( COLUMNBREAKTAIL[$text] columnbreaktailtext )
                {
                CommonTree root_1 = (CommonTree)adaptor.nil();
                root_1 = (CommonTree)adaptor.becomeRoot(adaptor.create(COLUMNBREAKTAIL, input.toString(retval.start,input.LT(-1))), root_1);

                adaptor.addChild(root_1, stream_columnbreaktailtext.next());

                adaptor.addChild(root_0, root_1);
                }

            }



            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end columnbreaktail

    public static class columnbreaktailtext_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start columnbreaktailtext
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:133:1: columnbreaktailtext : ( SPACE | LEXNEWLINE )+ ;
    public final columnbreaktailtext_return columnbreaktailtext() throws RecognitionException {
        columnbreaktailtext_return retval = new columnbreaktailtext_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set37=null;

        CommonTree set37_tree=null;

        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:134:2: ( ( SPACE | LEXNEWLINE )+ )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:134:4: ( SPACE | LEXNEWLINE )+
            {
            root_0 = (CommonTree)adaptor.nil();

            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:134:4: ( SPACE | LEXNEWLINE )+
            int cnt12=0;
            loop12:
            do {
                int alt12=2;
                int LA12_0 = input.LA(1);

                if ( ((LA12_0>=LEXNEWLINE && LA12_0<=SPACE)) ) {
                    alt12=1;
                }


                switch (alt12) {
            	case 1 :
            	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:
            	    {
            	    set37=(Token)input.LT(1);
            	    if ( (input.LA(1)>=LEXNEWLINE && input.LA(1)<=SPACE) ) {
            	        input.consume();
            	        adaptor.addChild(root_0, adaptor.create(set37));
            	        errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_columnbreaktailtext553);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt12 >= 1 ) break loop12;
                        EarlyExitException eee =
                            new EarlyExitException(12, input);
                        throw eee;
                }
                cnt12++;
            } while (true);


            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end columnbreaktailtext

    public static class attributestext_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start attributestext
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:137:1: attributestext : ( LITERALS | SPACE ) ( EXCLM | LITERALS | MINUS | SPACE )* ;
    public final attributestext_return attributestext() throws RecognitionException {
        attributestext_return retval = new attributestext_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set38=null;
        Token set39=null;

        CommonTree set38_tree=null;
        CommonTree set39_tree=null;

        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:138:2: ( ( LITERALS | SPACE ) ( EXCLM | LITERALS | MINUS | SPACE )* )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:138:4: ( LITERALS | SPACE ) ( EXCLM | LITERALS | MINUS | SPACE )*
            {
            root_0 = (CommonTree)adaptor.nil();

            set38=(Token)input.LT(1);
            if ( input.LA(1)==SPACE||input.LA(1)==LITERALS ) {
                input.consume();
                adaptor.addChild(root_0, adaptor.create(set38));
                errorRecovery=false;
            }
            else {
                MismatchedSetException mse =
                    new MismatchedSetException(null,input);
                recoverFromMismatchedSet(input,mse,FOLLOW_set_in_attributestext568);    throw mse;
            }

            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:138:21: ( EXCLM | LITERALS | MINUS | SPACE )*
            loop13:
            do {
                int alt13=2;
                int LA13_0 = input.LA(1);

                if ( (LA13_0==SPACE||(LA13_0>=LITERALS && LA13_0<=MINUS)) ) {
                    alt13=1;
                }


                switch (alt13) {
            	case 1 :
            	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:
            	    {
            	    set39=(Token)input.LT(1);
            	    if ( input.LA(1)==SPACE||(input.LA(1)>=LITERALS && input.LA(1)<=MINUS) ) {
            	        input.consume();
            	        adaptor.addChild(root_0, adaptor.create(set39));
            	        errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_attributestext574);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    break loop13;
                }
            } while (true);


            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end attributestext

    public static class freetext_return extends ParserRuleReturnScope {
        CommonTree tree;
        public Object getTree() { return tree; }
    };

    // $ANTLR start freetext
    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:139:1: freetext : ( EXCLM | LITERALS | MINUS | LEXNEWLINE | SPACE )+ ;
    public final freetext_return freetext() throws RecognitionException {
        freetext_return retval = new freetext_return();
        retval.start = input.LT(1);

        CommonTree root_0 = null;

        Token set40=null;

        CommonTree set40_tree=null;

        try {
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:140:2: ( ( EXCLM | LITERALS | MINUS | LEXNEWLINE | SPACE )+ )
            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:140:4: ( EXCLM | LITERALS | MINUS | LEXNEWLINE | SPACE )+
            {
            root_0 = (CommonTree)adaptor.nil();

            // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:140:4: ( EXCLM | LITERALS | MINUS | LEXNEWLINE | SPACE )+
            int cnt14=0;
            loop14:
            do {
                int alt14=2;
                int LA14_0 = input.LA(1);

                if ( ((LA14_0>=LEXNEWLINE && LA14_0<=SPACE)||(LA14_0>=LITERALS && LA14_0<=MINUS)) ) {
                    alt14=1;
                }


                switch (alt14) {
            	case 1 :
            	    // E:\\Projects\\Programming\\Java\\Wiki\\src\\org\\wikipedia\\vlsergey\\parser\\table\\Table.g:
            	    {
            	    set40=(Token)input.LT(1);
            	    if ( (input.LA(1)>=LEXNEWLINE && input.LA(1)<=SPACE)||(input.LA(1)>=LITERALS && input.LA(1)<=MINUS) ) {
            	        input.consume();
            	        adaptor.addChild(root_0, adaptor.create(set40));
            	        errorRecovery=false;
            	    }
            	    else {
            	        MismatchedSetException mse =
            	            new MismatchedSetException(null,input);
            	        recoverFromMismatchedSet(input,mse,FOLLOW_set_in_freetext591);    throw mse;
            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt14 >= 1 ) break loop14;
                        EarlyExitException eee =
                            new EarlyExitException(14, input);
                        throw eee;
                }
                cnt14++;
            } while (true);


            }

            retval.stop = input.LT(-1);

                retval.tree = (CommonTree)adaptor.rulePostProcessing(root_0);
                adaptor.setTokenBoundaries(retval.tree, retval.start, retval.stop);

        }
        catch (RecognitionException re) {
            reportError(re);
            recover(input,re);
        }
        finally {
        }
        return retval;
    }
    // $ANTLR end freetext


    protected DFA7 dfa7 = new DFA7(this);
    protected DFA8 dfa8 = new DFA8(this);
    protected DFA10 dfa10 = new DFA10(this);
    static final String DFA7_eotS =
        "\7\uffff";
    static final String DFA7_eofS =
        "\2\2\1\uffff\2\2\1\uffff\1\2";
    static final String DFA7_minS =
        "\2\17\1\uffff\2\17\1\uffff\1\17";
    static final String DFA7_maxS =
        "\2\30\1\uffff\2\30\1\uffff\1\30";
    static final String DFA7_acceptS =
        "\2\uffff\1\2\2\uffff\1\1\1\uffff";
    static final String DFA7_specialS =
        "\7\uffff}>";
    static final String[] DFA7_transitionS = {
            "\1\2\1\1\2\2\1\uffff\2\2\1\3\2\2",
            "\1\2\1\4\2\2\1\5\2\2\3\6",
            "",
            "\1\2\1\4\2\2\1\5\2\2\3\6",
            "\1\2\1\4\2\2\1\5\2\2\3\6",
            "",
            "\1\2\1\4\2\2\1\5\2\2\3\6"
    };

    static final short[] DFA7_eot = DFA.unpackEncodedString(DFA7_eotS);
    static final short[] DFA7_eof = DFA.unpackEncodedString(DFA7_eofS);
    static final char[] DFA7_min = DFA.unpackEncodedStringToUnsignedChars(DFA7_minS);
    static final char[] DFA7_max = DFA.unpackEncodedStringToUnsignedChars(DFA7_maxS);
    static final short[] DFA7_accept = DFA.unpackEncodedString(DFA7_acceptS);
    static final short[] DFA7_special = DFA.unpackEncodedString(DFA7_specialS);
    static final short[][] DFA7_transition;

    static {
        int numStates = DFA7_transitionS.length;
        DFA7_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA7_transition[i] = DFA.unpackEncodedString(DFA7_transitionS[i]);
        }
    }

    class DFA7 extends DFA {

        public DFA7(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 7;
            this.eot = DFA7_eot;
            this.eof = DFA7_eof;
            this.min = DFA7_min;
            this.max = DFA7_max;
            this.accept = DFA7_accept;
            this.special = DFA7_special;
            this.transition = DFA7_transition;
        }
        public String getDescription() {
            return "69:22: ( cellattributes cellattributesborder )?";
        }
    }
    static final String DFA8_eotS =
        "\7\uffff";
    static final String DFA8_eofS =
        "\2\2\1\uffff\3\2\1\uffff";
    static final String DFA8_minS =
        "\2\17\1\uffff\3\17\1\uffff";
    static final String DFA8_maxS =
        "\2\30\1\uffff\3\30\1\uffff";
    static final String DFA8_acceptS =
        "\2\uffff\1\2\3\uffff\1\1";
    static final String DFA8_specialS =
        "\7\uffff}>";
    static final String[] DFA8_transitionS = {
            "\1\2\1\1\2\2\1\uffff\2\2\1\3\2\2",
            "\1\2\1\4\2\2\1\6\2\2\3\5",
            "",
            "\1\2\1\4\2\2\1\6\2\2\3\5",
            "\1\2\1\4\2\2\1\6\2\2\3\5",
            "\1\2\1\4\2\2\1\6\2\2\3\5",
            ""
    };

    static final short[] DFA8_eot = DFA.unpackEncodedString(DFA8_eotS);
    static final short[] DFA8_eof = DFA.unpackEncodedString(DFA8_eofS);
    static final char[] DFA8_min = DFA.unpackEncodedStringToUnsignedChars(DFA8_minS);
    static final char[] DFA8_max = DFA.unpackEncodedStringToUnsignedChars(DFA8_maxS);
    static final short[] DFA8_accept = DFA.unpackEncodedString(DFA8_acceptS);
    static final short[] DFA8_special = DFA.unpackEncodedString(DFA8_specialS);
    static final short[][] DFA8_transition;

    static {
        int numStates = DFA8_transitionS.length;
        DFA8_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA8_transition[i] = DFA.unpackEncodedString(DFA8_transitionS[i]);
        }
    }

    class DFA8 extends DFA {

        public DFA8(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 8;
            this.eot = DFA8_eot;
            this.eof = DFA8_eof;
            this.min = DFA8_min;
            this.max = DFA8_max;
            this.accept = DFA8_accept;
            this.special = DFA8_special;
            this.transition = DFA8_transition;
        }
        public String getDescription() {
            return "74:25: ( cellattributes cellattributesborder )?";
        }
    }
    static final String DFA10_eotS =
        "\7\uffff";
    static final String DFA10_eofS =
        "\2\2\1\uffff\2\2\1\uffff\1\2";
    static final String DFA10_minS =
        "\2\17\1\uffff\2\17\1\uffff\1\17";
    static final String DFA10_maxS =
        "\2\30\1\uffff\2\30\1\uffff\1\30";
    static final String DFA10_acceptS =
        "\2\uffff\1\2\2\uffff\1\1\1\uffff";
    static final String DFA10_specialS =
        "\7\uffff}>";
    static final String[] DFA10_transitionS = {
            "\1\2\1\1\2\2\1\uffff\2\2\1\3\2\2",
            "\1\2\1\4\2\2\1\5\2\2\3\6",
            "",
            "\1\2\1\4\2\2\1\5\2\2\3\6",
            "\1\2\1\4\2\2\1\5\2\2\3\6",
            "",
            "\1\2\1\4\2\2\1\5\2\2\3\6"
    };

    static final short[] DFA10_eot = DFA.unpackEncodedString(DFA10_eotS);
    static final short[] DFA10_eof = DFA.unpackEncodedString(DFA10_eofS);
    static final char[] DFA10_min = DFA.unpackEncodedStringToUnsignedChars(DFA10_minS);
    static final char[] DFA10_max = DFA.unpackEncodedStringToUnsignedChars(DFA10_maxS);
    static final short[] DFA10_accept = DFA.unpackEncodedString(DFA10_acceptS);
    static final short[] DFA10_special = DFA.unpackEncodedString(DFA10_specialS);
    static final short[][] DFA10_transition;

    static {
        int numStates = DFA10_transitionS.length;
        DFA10_transition = new short[numStates][];
        for (int i=0; i<numStates; i++) {
            DFA10_transition[i] = DFA.unpackEncodedString(DFA10_transitionS[i]);
        }
    }

    class DFA10 extends DFA {

        public DFA10(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 10;
            this.eot = DFA10_eot;
            this.eof = DFA10_eof;
            this.min = DFA10_min;
            this.max = DFA10_max;
            this.accept = DFA10_accept;
            this.special = DFA10_special;
            this.transition = DFA10_transition;
        }
        public String getDescription() {
            return "102:23: ( cellattributes cellattributesborder )?";
        }
    }
 

    public static final BitSet FOLLOW_tableattributes_in_table103 = new BitSet(new long[]{0x0000000000260000L});
    public static final BitSet FOLLOW_cellsline_in_table106 = new BitSet(new long[]{0x0000000000278000L});
    public static final BitSet FOLLOW_tabletail_in_table109 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_EOF_in_table111 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_attributestext_in_tableattributes121 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_tabletailtext_in_tabletail143 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_tabletailtext165 = new BitSet(new long[]{0x0000000000018002L});
    public static final BitSet FOLLOW_columnbreak_in_cellsline179 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_newlinecell_in_cellsline183 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_newemptydouble_in_cellsline185 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_samelinecell_in_cellsline188 = new BitSet(new long[]{0x0000000000100002L});
    public static final BitSet FOLLOW_newlinecellborder_in_newlinecell199 = new BitSet(new long[]{0x0000000001C18002L});
    public static final BitSet FOLLOW_cellattributes_in_newlinecell202 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_cellattributesborder_in_newlinecell204 = new BitSet(new long[]{0x0000000001C18002L});
    public static final BitSet FOLLOW_cellchildren_in_newlinecell208 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_newemptydoubleborder_in_newemptydouble240 = new BitSet(new long[]{0x0000000001C18002L});
    public static final BitSet FOLLOW_cellattributes_in_newemptydouble243 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_cellattributesborder_in_newemptydouble245 = new BitSet(new long[]{0x0000000001C18002L});
    public static final BitSet FOLLOW_cellchildren_in_newemptydouble249 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NEWLINETRIPLELINE_in_newemptydoubleborder289 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_freetext_in_cellchildren298 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_NEWLINECELLBORDERTEXT_in_newlinecellborder322 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_attributestext_in_cellattributes345 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_LINE_in_cellattributesborder367 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_samelinecellborder_in_samelinecell389 = new BitSet(new long[]{0x0000000001C18002L});
    public static final BitSet FOLLOW_cellattributes_in_samelinecell392 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_cellattributesborder_in_samelinecell394 = new BitSet(new long[]{0x0000000001C18002L});
    public static final BitSet FOLLOW_cellchildren_in_samelinecell398 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_SAMELINECELLBORDERTEXT_in_samelinecellborder430 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_columnbreaktext_in_columnbreak451 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_columnbreakborder_in_columnbreaktext471 = new BitSet(new long[]{0x0000000000418002L});
    public static final BitSet FOLLOW_columnbreakattributes_in_columnbreaktext474 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_columnbreaktail_in_columnbreaktext476 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_COLUMNBREAKBORDERTEXT_in_columnbreakborder487 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_attributestext_in_columnbreakattributes509 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_columnbreaktailtext_in_columnbreaktail531 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_set_in_columnbreaktailtext553 = new BitSet(new long[]{0x0000000000018002L});
    public static final BitSet FOLLOW_set_in_attributestext568 = new BitSet(new long[]{0x0000000001C10002L});
    public static final BitSet FOLLOW_set_in_attributestext574 = new BitSet(new long[]{0x0000000001C10002L});
    public static final BitSet FOLLOW_set_in_freetext591 = new BitSet(new long[]{0x0000000001C18002L});

}